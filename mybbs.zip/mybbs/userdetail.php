<head>
	<title>论坛系统--编辑</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<link rel="stylesheet" type="text/css" href="style/style.css"/>
	<script>   //定义javascript函数
		function check(){   //检查用户提交的数据是否符合要求
			if(document.userForm.uPass.value == ""){
				alert("密码不能为空");
				return false;
			}
			if(document.userForm.uPass.value != document.userForm.uPass1.value){   //如果两次密码不同
				alert("两次密码不同");
				return false;
			}
		}
	</script>
</head>
<body>
<?php
require_once("comm/comm.php");//引入外部文件
pageHead();//调用函数输出页面头部
?>
<!--页面中部：注册表单-->
<div align="center" class="t">
<form action="doUpdateUser.php" method="post" name="userForm" onsubmit="return check()"
enctype="multipart/form-data">
<br>新的密码：<input type="password" name="uPass"><br>
重复密码：<input type="password" name="uPass1"><br>
性别：
<?php
if($_SESSION["CURRENT_USER"]["gender"] == 1){
	echo "女<input type='radio' name='gender' value='1' checked='checked'>男<input type='radio' name='gender' value='2'><br>";
}else{
	echo "女<input type='radio' name='gender' value='1'>男<input type='radio' name='gender' value='2' checked='checked'><br>";
}
?>
请选择头像<br>
<?php
$flag = true;  //定义一个指示变量，标识当前用户头像为自定义头像
for($i=1;$i<=15;$i++){  //循环15次，输出15个头像以及对应的单选框

	if($_SESSION["CURRENT_USER"]["head"] == "$i.jpg"){
		echo "<img src='image/head/$i.jpg'><input type='radio' name='head' value='$i.jpg' checked='checked'>";
		$flag = false;//因为检测到用户头像为系统头像，更新指示变量取值
	}else{
		echo "<img src='image/head/$i.jpg'><input type='radio' name='head' value='$i.jpg'>";
	}
	if($i%5 == 0){   //每五个头像换一行
	echo "<br>";
	}
}

if($flag){//如果已登录用户的头像为自定义头像
	$myhead = $_SESSION["CURRENT_USER"]["head"];//从session会话中提取你的自定义头像的名字
	echo "<img src='image/head/$myhead'><input type='radio' name='head' value='$myhead' checked='checked'>";
}

?>
<br>
<input type="hidden" name="MAX_FILE_SIZE" value="102400">
自定义头像：<input type="file" name="myhead">(注意：头像大小不能超过100k)
<br>
<input type="submit" value="修改">
</form>
</div>

<?php
pageFoot();//调用函数输出页面尾部
?>
</body>