<head>
	<title>论坛系统--注册</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<script>
	function init(){  //初始化头像,默认第一张图片被选中
		document.regForm.head[0].checked=true;
	}
	function check(){  //验证数据的合法性
		if(document.regForm.uName.value == ""){
		alert("用户昵称不能为空!");
		return false;
	}
	if(document.regForm.uPass.value == ""){
		alert("用户密码不能为空!");
		return false;
	}
	if(document.regForm.uPass.value != document.regForm.uPass1.value){
		alert("两次密码不同!");
		return false;
	}
	}
	</script>
</head>
<body onload="init()">
<?php
require_once("comm/comm.php");//引入外部文件
pageHead();//调用函数输出页面头部
?>
<!--页面头部：论坛导航-->
<div>
	&gt;&gt;<a href="index.php"><b>论坛首页</b></a>
</div>
<br>
<!--页面中部：注册表单-->
<div align="center" class="t">
<form action="doReg.php" method="post" name="regForm" onsubmit="return check()">
<br>用户昵称：<input type="text" name="uName"><br>
用户密码：<input type="password" name="uPass"><br>
重复密码：<input type="password" name="uPass1"><br>
性别：女<input type="radio" name="gender" value="1" checked="checked">
男<input type="radio" name="gender" value="2"><br>
请选择头像<br>
<?php
for($i=1;$i<=15;$i++){  //循环15次，输出15个头像以及对应的单选框
	echo "<img src='image/head/$i.jpg'><input type='radio' name='head' value='$i.jpg'>";
	if($i % 5 == 0){   //每五个头像换一行
	echo "<br>";
	}
}
?>
<br>
<input type="submit" value="注册">
</form>
</div>
<?php
pageFoot();//调用函数输出页面尾部
?>
</body>