<head>
	<title>论坛系统  列表页</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<link rel="stylesheet" type="text/css" href="style/style.css"/>
</head>
<body>
<?php
require_once("comm/comm.php");//引入外部文件
pageHead();//调用函数输出页面头部
?>
<!--页面头部：论坛导航-->
<?PHP
require_once("comm/board.dao.php");//引入外部文件
require_once("comm/topic.dao.php");
require_once("comm/reply.dao.php");
$boardId = $_GET["boardId"];//获取地址栏传递的数据：板块编号
$curPage = $_GET["currentPage"];//获取地址栏传递的数据：列表页页码
$board = findBoard($boardId);//根据当前板块编号获取板块信息
$boardName = $board[0]["boardName"];//从$board数组中提取当前板块所有信息里的板块名称
?>
<div>
	&gt;&gt;<a href='index.php'><b>论坛首页</b></a>
	&gt;&gt;<a href='list.php?boardId=<?php echo $boardId;?>&currentPage=1'><b><?php echo $boardName;?><b></a>
</div>
<br>
<!--页面头部:发帖链接-->
<div>
	<a href="post.php?boardId=<?php echo $boardId;?>"><img src="image/post.gif"></a>
</div>
<br>


<!--页面中部：上下跳转与分页处理-->
<?php
$pagesize = $GLOBALS["cfg"]["pagesize"];//$GLOBALS为全局变量，用来获取全局范围内定义的变量（页面容量）
$num = findCountTopic($boardId);//统计当前板块下帖子总数
if($num % $pagesize == 0){//如果帖子总数对页面容量取余，余数为0
	$pages = $num/$pagesize;//页面总数等于帖子总数除以页面容量的商
}else{
	$pages = (int)($num/$pagesize) + 1;//页面总数等于帖子总数除以页面容量的商取整,再加1
}
$text ="";
if($curPage == 1){//如果当前页码为1，上一页不带超链接
	$text = "上一页 | ";
}else{//如果当前页码不是第一页，上一页必然带超链接
	$page = $curPage-1;//定义了上一页跳转的目的地
	$text = "<a href='list.php?boardId=$boardId&currentPage=$page'>上一页</a> | ";
}
if($curPage == $pages){//如果当前页码等于总页数，下一页不带超链接
	$text .="下一页 | ";
}else{
	$page = $curPage+1;//定义下一页跳转时的目的页码
	$text .="<a href='list.php?boardId=$boardId&currentPage=$page'>下一页</a> | ";
}
$text .="当前第 $curPage 页| 共 $pages 页";
echo $text;
?>
<br><br>


<!--页面中部：帖子列表-->
<div class="t">
<table width="100%" cellspacing="0" cellpadding="0" align="center">
	<tr class="tr2"  align='center'>
		<td width="5%">&nbsp;</td>
		<td width="75%">话题</td>
		<td width="10%">作者</td>
		<td width="10%">回复</td>
	</tr>

	<?php
$topics = findListTopic($boardId,$curPage);//获取当前板块下$curPage页的帖子列表
foreach($topics as $value){//遍历$topics,每次匹配其中一条帖子记录
	$title = $value["title"];//从当前帖子信息中提取帖子标题
	$uName = $value["uName"];//从当前帖子信息中提取发帖人账号
	$topicId = $value["topicId"];//从当前帖子信息中提取帖子编号
	$replyNum = findCountReply($topicId);///统计当前帖子下的回复数目

	echo "<tr class='tr3'>";
		echo "<td align='center'><img src='image/topic.gif'></td>";
		echo "<td><a href='detail.php?boardId=$boardId&currentPage=$curPage&topicId=$topicId&currentReplyPage=1'>$title</a></td>";
		echo "<td align='center'>$uName</td>";//添加超链接，传递四个参数
		echo "<td align='center'>$replyNum</td>";
	echo "</tr>";
}
?>

</table>
</div>
<br>


<?php
pageFoot();//调用函数输出页面尾部
?>
</body>