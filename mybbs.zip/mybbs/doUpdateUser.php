<?php
if(empty($_POST))//如果自定义头像超过了8M
	echo "<script>alert('自定义头像超过了8M');location.href='userdetail.php';</script>";
header("content-type:text/html;charset=utf-8");//指定字符编码
require_once("comm/user.dao.php");//引入外部接口文件
session_start();//开启会话机制
if(isset($_SESSION["CURRENT_USER"])){//isset函数：判断变量是否被定义，如果$_SESSION["CURRENT_USER"]定义过，证明用户已经登录了
   $user =$_SESSION["CURRENT_USER"];//提取登录用户的所有信息
   $id = $user["uId"];//从所有信息中提取用户编号

if($_FILES["myhead"]["error"] == 0){//如果状态码为0，代表文件初步上传成功
		$name = $_FILES["myhead"]["name"];//采集上传文件的名字
		$tmp = $_FILES["myhead"]["tmp_name"];//采集服务器端形成的临时文件名
		$dest = "image/head/".$name;//指定文件上传成功后的目标路径
		move_uploaded_file($tmp,$dest);//调用移动函数，实现文件上传
		$rs = updateUser($id,$_POST["uPass"],$_POST["gender"],$name); //调用函数updateUser，修改用户信息（自定义头像）
	}elseif($_FILES["myhead"]["error"] == 1 || $_FILES["myhead"]["error"] == 2){//如果自定义头像超过100k
		echo "<script>alert('自定义头像超过了100K!');location.href='userdetail.php';</script>";
	}else{//如果网络有问题或者未选择头像
		$rs = updateUser($id,$_POST["uPass"],$_POST["gender"],$_POST["head"]);//调用函数updateUser，修改用户信息（自定义头像）
	}

   if($rs == 1){//如果返回1，证明影响了数据库里的一行记录，也就意味着修改成功
	   $outcome = findUserById($id); //查询已经登录用户的所有最新消息
	   $_SESSION["CURRENT_USER"] = $outcome[0];//替换session会话中的个人信息
	   echo "<script>alert('恭喜，信息修改成功！');location.href='index.php';</script>";
   }else{
       echo "<script>alert('对不起，信息修改失败！');location.href='userdetail.php';</script>";
   }

}
?>
