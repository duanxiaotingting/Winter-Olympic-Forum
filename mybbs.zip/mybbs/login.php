<head>
	<title>论坛系统--登录</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<script>
	function check(){  //检查用户提交的数据是否符合要求
		if(document.loginForm.uName.value == ""){  //如果用户昵称为空
		alert("用户昵称不能为空!");
		return false;
	}
	if(document.loginForm.uPass.value == ""){  //如果用户密码为空
		alert("用户密码不能为空!");
		return false;
	}
}
</script>
</head>
<body>
<?php
require_once("comm/comm.php");//引入外部文件
pageHead();//调用函数输出页面头部
?>
<!--页面头部：论坛导航-->
<div>
	&gt;&gt;<a href="index.php"><b>论坛首页</b></a>
</div>
<br>
<!--页面中部：登录表单-->
<div align="center" class="t">
<form action="doLogin.php" method="post" name="loginForm" onsubmit="return check()">
<br>用户昵称：<input type="text" name="uName"><br><br>
用户密码：<input type="password" name="uPass"><br><br>
<input type="submit" value="登录">
</form>
</div>
<?php
pageFoot();//调用函数输出页面尾部
?>
</body>