<?php
header("content-type:text/html;charset=utf-8");//字符编码设置
session_start();//开启会话
session_destroy();//销毁会话
echo "<script>alert('注销成功！');location.href='index.php';</script>";//弹窗提醒，页面跳转
?>