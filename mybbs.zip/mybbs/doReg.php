<?php
header("content-type:text/html;charset=utf-8");
require_once("comm/user.dao.php");//引入外部接口文件
if(!empty($_POST)){
	$rs = findUser($_POST["uName"]);//根据用户名查询用户信息
	if(empty($rs)){//如果查询结果为空，证明你的账号很新
		addUser($_POST["uName"],$_POST["uPass"],$_POST["gender"],$_POST["head"]);//新增用户信息
		echo "<script>alert('恭喜，注册成功');location.href='login.php';</script>";
	}else{//如果查询结果非空，证明此昵称已经被占用
		echo "<script>alert('对不起，此昵称已被占用');location.href='reg.php';</script>";
	}
}

?>