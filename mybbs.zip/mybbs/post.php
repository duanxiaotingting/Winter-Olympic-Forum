<head>
	<title>论坛系统--信息发布</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<link rel="stylesheet" type="text/css" href="style/style.css"/>
		<script src="kindeditor/kindeditor.js"></script>
	<script src="kindeditor/lang/zh_CN.js"></script>
	<script>
		var editor;						//定义文本编辑器
		KindEditor.ready(function(K){	//创建编辑器组件，并将其绑定在多行文本输入框上
			editor = K.create('textarea[name="content"]',{
				cssPath:'kindeditor/plugins/code/prettify.css',
				allowImageUpload:false,allowFlashUpload:false,allowMediaUpload:false});
			prettyPrint();
		});
		function valid(){				//表单数据合法性验证
			if(document.postForm.title.value == ""){		//判断标题是否为空
				alert("标题不能为空");
				return false;
			}
			content = editor.html();						//获取富文本编辑框中的内容
			if(content == ""){								//判断内容是否为空
				alert("内容不能为空");
				return false;
			}               
		}
		function init(){              	//初始化函数，判断当前操作为新帖发表还是回帖发表
			if(document.postForm.topicId.value != 0){		//如果topicId非空，说明是回帖操作
				document.postForm.action = "doReply.php";	//将表单数据提交到doReply.php中
			}
		}

	</script>



</head>
<body onload="init()">
<?php
require_once("comm/comm.php");//引入外部文件
pageHead();//调用函数输出页面头部
?>
<!--页面头部：论坛导航-->
<?PHP
require_once("comm/board.dao.php");//引入外部文件
require_once("comm/topic.dao.php");
require_once("comm/reply.dao.php");
$boardId = $_GET["boardId"];//获取地址栏传递的数据：板块编号
$board = findBoard($boardId);//根据当前板块编号获取板块信息
$boardName = $board[0]["boardName"];//从$board数组中提取当前板块所有信息里的板块名称
?>
<div>
	&gt;&gt;<a href='index.php'><b>论坛首页</b></a>
	&gt;&gt;<a href='list.php?boardId=<?php echo $boardId;?>&currentPage=1'><b><?php echo $boardName;?><b></a>
</div>
<br>

<!--页面中部：操作判断（发帖？回帖？）-->
<?php
$curPage = empty($_GET["currentPage"])?0:$_GET["currentPage"];   //条件运算符
$topicId = empty($_GET["topicId"])?0:$_GET["topicId"];//如果地址栏传递了topicId参数，将采集到的参数放在变量$topicId里，否则，把0放入变量中
if($topicId == 0){
	$text = "发表新帖";//定义变量，存放当前操作内容
}else{
	$topic = findTopicById($topicId);//根据帖子编号查询帖子详细内容，结果为一个二维数组
	$title = $topic[0]["title"];//从帖子详细信息中提取帖子标题
	$text = "回复".$title;//更新操作内容
}
?>

<!--页面中部：表单设计（三行两列表格）-->
<div class="t">
<form action="doPost.php" method="post" name="postForm" onsubmit="return valid()">
	<input type="hidden" name="boardId" value="<?php echo $boardId;?>">
	<input type="hidden" name="curPage" value="<?php echo $curPage;?>">
	<input type="hidden" name="topicId" value="<?php echo $topicId;?>">



	<table>
		<tr>
			<th colspan="2" class="h"><?php echo $text;?></th>
		</tr>
		<tr class="tr3">
		<th>标题</th>
		<th><input type="text" name="title" size="70"></th>
		</tr>
		<tr class="tr3">
		<th>内容</th>
		<th><textarea name="content" style="width:500px;height:250px"></textarea></th>
		</tr>
	</table>
	<div align="center">
		<input type="submit" value="提交">&nbsp;&nbsp;&nbsp;<input type="reset" value="重置">
</form>
</div>






<?php
pageFoot();//调用函数输出页面尾部
?>
</body>