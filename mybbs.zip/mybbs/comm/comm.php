<?php
require_once("config.php");		//引入系统配置文件      
//服务器连接与数据库选择
function getConnect() {         //使用$GLOBALS引用全局作用域中可用的全部变量
    $link = mysqli_connect($GLOBALS["cfg"]["hostname"],$GLOBALS["cfg"]["username"],$GLOBALS["cfg"]["password"]) or die("服务器连接失败");
	mysqli_query($link,"set names utf8") or die("字符集设置失败");
    mysqli_select_db($link,$GLOBALS["cfg"]["dbname"]) or die("数据库选择失败");
    return $link;
}
//对数据表记录执行查询操作
function execQuery($strQuery){
    $outcome = array();			//将变量初始化为空数组
    $link = getConnect();		//调用函数getConnect()获取服务器连接标识
    $rs = mysqli_query($link,$strQuery) or die("数据表查询失败");
    for ($i=0;$i<mysqli_num_rows($rs);$i++) {     //循环读取数据查询结果集
        $outcome[$i] = mysqli_fetch_array($rs);   //将结果集匹配成数组
    }
    mysqli_free_result($rs);    //释放结果集
    mysqli_close($link);        //关闭连接
    return $outcome;            //返回满足条件的数据记录（二维数组）
}
//对数据表记录执行非查询操作（插入、修改、删除）
function execUpdate($strUpdate){
    $link = getConnect();       //调用函数getConnect()获取服务器连接标识
    $rs = mysqli_query($link,$strUpdate) or die("数据表操作失败");
    $outcome = mysqli_affected_rows($link);    //返回最近一次增删改操作所影响的记录行数
    mysqli_close($link);		//关闭连接
    return $outcome;            //返回被影响行数（整数）    
}
//定义页面头部函数(论坛logo、登录状态)
function pageHead(){
	echo "<!--页面头部：论坛logo-->
	<div>
		<img src='image/logo.png' style='height:120px;width:220px'>
	</div>
	<br>
	<!--页面头部:登录状态-->
	<div class='h'>";

	session_start();
	if(isset($_SESSION["CURRENT_USER"])){
		$user = $_SESSION["CURRENT_USER"];
		$name = $user["uName"];
		echo "您好：<a href='userdetail.php'>".$name."</a>&nbsp;|&nbsp;<a href='doLogout.php'>登出</a>";
	}else{
		echo "您尚未<a href='login.php'>登录</a>&nbsp;|&nbsp;<a href='reg.php'>注册</a>";
	}

	echo "</div>
	<br>";
}
//定义页面尾部函数（版权声明）
function pageFoot(){
	echo "<!--页面尾部：版权声明-->
	<div align='center'>
		2008-2022冬奥会版权所有
	</div>";
}
?>
