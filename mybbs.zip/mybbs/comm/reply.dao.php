<?php
require_once("comm.php");
/*
 * 新增主贴记录
 * @param <type> $uId  回帖人编号
 * @param <type> $topicId  回帖所属版块编号
 * @param <type> $title 标题
 * @param <type> $content 内容
 */
function addReply($uId,$topicId,$title,$content){
    $addStr = "insert into tbl_reply(uId,topicId,title,content) values($uId,$topicId,'$title','$content')";
    $rs = execUpdate($addStr);      //执行插入操作
    return $rs;                     //返回值为整数
}
/*
 * 修改回贴记录
 * @param <type> $replyId 回贴编号
 * @param <type> $title  标题
 * @param <type> $content  内容
 */
function updatereply($replyId,$title,$content){
    date_default_timezone_set("Asia/Shanghai");       //设置默认时区为上海
    $modifyTime = date("Y-m-d H:i:s");                //date函数用于格式化日期时间
    $updateStr = "update tbl_reply set title='$title',content='$content',modifyTime='$modifyTime' where replyId=$replyId" ;
    $rs = execUpdate($updateStr);   //执行修改操作
    return $rs;						//返回值为整数
}
/*
 * 删除回贴记录
 * @param <type> $topicId 回贴编号
 */
function deleteReply($replyId){
    $delStr = "delete from tbl_reply where replyId= $replyId";
    $rs = execUpdate($delStr);      //执行删除操作
    return $rs;						//返回值为整数
}
/*
 * 根据回贴编号查询回贴信息及用户信息
 * @param <type> $topicId 回贴编号
 */
function findReplyById($replyId){   //主贴表与用户表相连
    $strQuery = "select * from tbl_reply r,tbl_user u where r.uId=u.uId and replyId=$replyId";
    $rs = execQuery($strQuery);		//执行查询操作
    return $rs;						//返回值为数组
}
/*
 * 统计某主贴下的主贴数目
 * @param <type> $boardId 版块编号
 */
function findCountReply($topicId){
    $strQuery = "select count(*) from tbl_reply where topicId=$topicId ";
    $rs = execQuery($strQuery);     //执行查询统计操作 
    return $rs[0][0];				//返回值为统计值
}
//分页查询某个主贴下的回复信息以及用户信息（参数：版块编号，当前访问页码）（返回值：数组）
function findListReply($topicId,$page){ 
	$length =$GLOBALS["cfg"]["pagesize"];//页面容量，从配置文件config.php中获取，使用$GLOBALS引用全局作用域中可用的全部变量
	$start = ($page-1)*$length;//计算某一页的初始值
	$rs = execQuery("select * from tbl_reply r,tbl_user u where r.uId=u.uId and topicId=$topicId order by publishTime desc
	 limit  $start,$length"); //定义SQL语句，limit用于表示当前页码中显示的记录初始值，长度
	return $rs;
}
?>