<?php
//引入公共程序文件
require_once("comm.php");
/*
 * 新增主贴记录
 * @param <type> $uId  发帖人编号
 * @param <type> $boardId  发帖所属版块编号
 * @param <type> $title 标题
 * @param <type> $content 内容
 */
function addTopic($uId,$boardId,$title,$content){
    $addStr = "insert into tbl_topic(uId,boardId,title,content) values($uId,$boardId,'$title','$content')";
    $rs = execUpdate($addStr);      //执行插入操作
    return $rs;                     //返回值为整数
}
/*
 * 修改主贴记录
 * @param <type> $topicId 主贴编号
 * @param <type> $title  标题
 * @param <type> $content  内容
 */
function updateTopic($topicId,$title,$content){
    date_default_timezone_set("Asia/Shanghai");       //设置默认时区为上海
    $modifyTime = date("Y-m-d H:i:s");                //date函数用于格式化日期时间
    $updateStr = "update tbl_topic set title='$title',content='$content',modifyTime='$modifyTime' where topicId=$topicId" ;
    $rs = execUpdate($updateStr);   //执行修改操作
    return $rs;						//返回值为整数
}
/*
 * 删除主贴记录
 * @param <type> $topicId 主贴编号
 */
function deleteTopic($topicId){
    $delStr = "delete from tbl_topic where topicId= $topicId";
    $rs = execUpdate($delStr);      //执行删除操作
    return $rs;						//返回值为整数
}
/*
 * 根据主贴编号查询主贴信息及用户信息
 * @param <type> $topicId 主贴编号
 */
function findTopicById($topicId){   //主贴表与用户表相连
    $strQuery = "select * from tbl_topic t,tbl_user u where t.uId=u.uId and topicId=$topicId";
    $rs = execQuery($strQuery);		//执行查询操作
    return $rs;						//返回值为数组
}
/*
 * 统计某版块下的主贴数目
 * @param <type> $boardId 版块编号
 */
function findCountTopic($boardId){
    $strQuery = "select count(*) from tbl_topic where boardId=$boardId ";
    $rs = execQuery($strQuery);     //执行查询统计操作 
    return $rs[0][0];				//返回值为统计值
}
/*
 * 查询某版块下最新的主贴信息及用户信息
 * @param <type> $boardId 版块编号
 */
//主贴表与用户表相连，limit 0,1用于返回第一条记录
function findLastTopic($boardId){    
    $strQuery = "select  * from tbl_topic t,tbl_user u where t.uId=u.uId and boardId=$boardId 
	order by publishTime desc limit 0,1";
    $rs = execQuery($strQuery);     //执行查询操作
    return $rs;						//返回值为数组
}
//分页查询某个版块下的主贴信息以及用户信息（参数：版块编号，当前访问页面）（返回值：数组）
function findListTopic($boardId,$page){
	$length = $GLOBALS["cfg"]["pagesize"];//页面容量，从配置文件config.php中提取，使用$GLOBALS引用全局作用域中可用的全部变量
	$start = ($page-1)*$length;//计算某一页的初始值
	$rs = execQuery("select * from tbl_topic t,tbl_user u where t.uId=u.uId and boardId=$boardId order by publishTime desc 
	limit $start,$length");//定义SQL语句，limit用于表示当前页码中显示的记录初始值，长度
	return $rs;
}
?>
