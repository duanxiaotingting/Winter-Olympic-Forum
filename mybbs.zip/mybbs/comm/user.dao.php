<?php
//引入公共程序文件
require_once("comm.php");
/*
 * 根据用户名查询用户信息
 * @param <type> $uName 用户名
 */
function findUser($uName) {
    $strQuery = "select * from tbl_user where uName='$uName'";   
    $rs = execQuery($strQuery);       //调用execQuery函数执行查询操作
    return $rs;         //返回值为数组
} 
/*
 * 根据用户编号查询用户信息
 * @param <type> $uId 用户编号
 */
function findUserById($uId) {
    $strQuery = "select * from tbl_user where uId=$uId"; 
    $rs = execQuery($strQuery);       //调用execQuery函数执行查询操作
    return $rs;       //返回值为数组
}  
/*
 * 新增用户信息
 * @param <type> $uName  用户名
 * @param <type> $uPass  密码
 * @param <type> $gender 性别
 * @param <type> $head   头像
 */
function addUser($uName,$uPass,$gender,$head) {
    //定义插入操作SQL语句
    $insertStr = "insert into tbl_user(uName,uPass,gender,head) values('$uName','$uPass',gender,'$head')";
    $rs = execUpdate($insertStr);    //调用execUpdate函数执行添加操作
    return $rs;          //返回值为整数
}
/*
 * 修改用户信息
 * @param <type> $id     用户编号
 * @param <type> $uPass  密码
 * @param <type> $gender 性别
 * @param <type> $head   头像
 */
function updateUser($uId,$uPass,$gender,$head) {
    //定义修改操作SQL语句
    $updateSql = "update tbl_user set uPass='$uPass',gender=$gender,head='$head' where uId=$uId";
    $rs = execUpdate($updateSql);      //调用execUpdate函数执行修改操作
    return $rs;       //返回值为整数
}
?>
