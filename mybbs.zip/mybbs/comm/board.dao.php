<?php
//引入公共程序文件
require_once("comm.php");
/*
 * 根据版块编号获取版块信息，以数组的形式给出查询结果
 * @param <type> $boardId 版块编号
 */
function findBoard($boardId) {
    $strQuery = "select * from tbl_board where boardId=$boardId ";
    $result = execQuery($strQuery);     //调用execQuery函数执行查询操作
    return $result;                     //返回值为数组
}
/*
 * 根据父版块编号获取子版块信息,以数组的形式给出查询的果
 * @param <type> $parentId 父版块编号
 */
function findListBoard($parentId) {
    $strQuery = "select * from tbl_board where parentId=$parentId ";
    $result = execQuery($strQuery);    //调用execQuery函数执行查询操作
    return $result;              	   //返回值为数组
}
?>
