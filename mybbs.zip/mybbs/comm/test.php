<?php
//require_once("topic.dao.php");
//$rs = findListTopic(4,2);
//var_dump($rs);
//require_once("reply.dao.php");
//$rs = addReply(1,1,'I like','I like');
//var_dump($rs);
//require_once("reply.dao.php");
//$rs = updateReply(1,'abc','abc');
//var_dump($rs);
//require_once("reply.dao.php");
//$rs = deleteReply(1);
//var_dump($rs);
//require_once("reply.dao.php");
//$rs = findReplyById(2);
//var_dump($rs);
//require_once("reply.dao.php");
//$rs = findCountReply(1);
//var_dump($rs);
require_once("reply.dao.php");
$rs = findListReply(8,1);
var_dump($rs);
?>
