<?php
$cfg["hostname"] = "localhost";  //设置mysql服务器的名称或地址
$cfg["username"] = "root";       //设置登录mysql的用户名
$cfg["password"] = "";           //设置登录mysql的密码
$cfg["dbname"] = "mybbs";        //设置所操作的数据库名称
$cfg["pagesize"] = 5;            //设置分页时每页显示的数量
?>
