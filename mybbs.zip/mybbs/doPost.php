<?php
header("content-type:text/html;charset=utf-8");//指定编码方式
require_once("comm/topic.dao.php");            //引入外部文件
session_start();  //开启会话机制
if(isset($_SESSION["CURRENT_USER"])){//判断session会话变量是否被定义
   $uId = $_SESSION["CURRENT_USER"]["uId"];//从session会话中提取用户编号信息
   $title = $_POST["title"];//获取表单提交的帖子标题
   $content  = $_POST["content"];//获取表单提交的帖子内容
   $boardId = $_POST["boardId"];//获取表单提交的板块编号
   $rs = addTopic($uId,$boardId,$title,$content);//向topic表中插入一条记录
   if($rs == 1)
   echo "<script>alert('恭喜，新帖发布成功！');location.href='list.php?boardId=$boardId&currentPage=1';</script>";
}else{
    echo "<script>alert('对不起，请先登录！');location.href='login.php';</script>";
}
?>