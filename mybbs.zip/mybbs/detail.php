<head>
	<title>论坛系统--详情页</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<link rel="stylesheet" type="text/css" href="style/style.css"/>
</head>
<body>
<?php
require_once("comm/comm.php");//引入外部文件
pageHead();//调用函数输出页面头部
?>
<!--页面头部：论坛导航-->
<?PHP
require_once("comm/board.dao.php");//引入外部文件
require_once("comm/topic.dao.php");
require_once("comm/reply.dao.php");
$boardId = $_GET["boardId"];//获取地址栏传递的数据：板块编号
$curPage = $_GET["currentPage"];//获取地址栏传递的数据：列表页页码
$board = findBoard($boardId);//根据当前板块编号获取板块信息
$boardName = $board[0]["boardName"];//从$board数组中提取当前板块所有信息里的板块名称
$topicId = $_GET["topicId"];//获取GET方式提交的帖子编号
$curReplyPage = $_GET["currentReplyPage"];//获取GET方式提交的详情页页码（地址栏传递）
?>
<div>
	&gt;&gt;<a href='index.php'><b>论坛首页</b></a>
	&gt;&gt;<a href='list.php?boardId=<?php echo $boardId;?>&currentPage=1'><b><?php echo $boardName;?><b></a>
</div>
<br>
<!--页面头部:发帖链接-->
<div>
	<a href="post.php?boardId=<?php echo $boardId;?>"><img src="image/post.gif"></a>
	<a href="post.php?boardId=<?php echo $boardId;?>&currentPage=<?php echo $curPage;?>&topicId=<?php echo $topicId;?>"><img src="image/reply.gif"></a>
</div>
<br>

<!--页面中部：上下跳转与分页处理-->
<?php
$pagesize = $GLOBALS["cfg"]["pagesize"];//$GLOBALS为全局变量，用来获取全局范围内定义的变量（页面容量）
$num = findCountReply($topicId);//统计当前板块下帖子总数
if($num % $pagesize == 0){//如果帖子总数对页面容量取余，余数为0
	$pages = $num/$pagesize;//页面总数等于帖子总数除以页面容量的商
}else{
	$pages = (int)($num/$pagesize) + 1;//页面总数等于帖子总数除以页面容量的商取整,再加1
}
$text ="";

if($pages == 0){//如果总页数为0，将总页数修改为1
	$pages = 1;
}

if($curReplyPage == 1){//如果当前页码为1，上一页不带超链接
	$text = "上一页 | ";
}else{//如果当前页码不是第一页，上一页必然带超链接
	$page = $curReplyPage-1;//定义了上一页跳转的目的地
	$text = "<a href='detail.php?boardId=$boardId&currentPage=$curPage&topicId=$topicId&currentReplyPage=$page'>上一页</a> | ";
}
if($curReplyPage == $pages){//如果当前页码等于总页数，下一页不带超链接
	$text .="下一页 | ";
}else{
	$page = $curReplyPage+1;//定义下一页跳转时的目的页码
	$text .="<a href='detail.php?boardId=$boardId&currentPage=$curPage&topicId=$topicId&currentReplyPage=$page'>下一页</a> | ";
}
$text .="当前第 $curReplyPage 页| 共 $pages 页";
echo $text;
?>
<br><br>


<!--页面中部：本页主题-->
<?php
$topic = findTopicById($topicId);//根据帖子编号获取帖子详细信息，结果为一个二维数组
$title = $topic[0]["title"];//从当前帖子所有信息中提取帖子标题
$content = $topic[0]["content"];//从当前帖子所有信息中提取帖子内容
$publishTime = $topic[0]["publishTime"];//从当前帖子所有信息中提取帖子发表时间
$modifyTime = $topic[0]["modifyTime"];//从当前帖子所有信息中提取帖子修改时间
$uName = $topic[0]["uName"];//提取发帖人昵称
$head = $topic[0]["head"];//提取发帖人头像
$regTime = $topic[0]["regTime"];//提取发帖人注册时间
?>
<div>
	<table width="100%" cellspacing="0" cellpadding="0">
		<tr>
			<th class="h"><font color="red"><b>本页主题：<?php echo $title;?></b></font></th>
		<tr>
	</table>
</div>

<!--页面中部：主贴布局设计-->
<div>
<table width="100%" cellspacing="0" cellpadding="0" bgcolor="pink">
	<tr class="tr1">
		<th width="20">
		<?php
			echo "<div><b>$uName</b></div>
			<div><img src='image/head/$head'></div>
			<div>注册：$regTime</div>";
			?>
		</th>
		<th  width="80">
		<?php
			echo "<div><h4>$title<h4></div>
			<div>$content</div>
			<div class='tipad gray'>发表：[$publishTime]&nbsp;&nbsp;&nbsp;最后修改：[$modifyTime]</div>";
		?>
		</th>
	</tr>
</table>
</div>


<!--页面中部：回帖信息显示-->
<?php
$replys = findListReply($topicId,$curReplyPage);//查询当前帖子当前页的所有回复信息，结果为二维数组
if(count($replys) > 0){//如果回复数目大于0条
	foreach($replys as $value){//循环访问数组$replys,每次取出一条回复匹配成$value
		$title = $value["title"];//从当前回帖所有信息中提取回帖标题
		$content = $value["content"];//从当前回帖所有信息中提取回帖内容
		$publishTime = $value["publishTime"];//从当前回帖所有信息中提取回帖发表时间
		$modifyTime = $value["modifyTime"];//从当前回帖所有信息中提取回帖修改时间
		$uName = $value["uName"];//提取回帖人昵称
		$head = $value["head"];//提取回帖人头像
		$regTime = $value["regTime"];//提取回帖人注册时间
	

		echo "<div class=t>";
		echo "<table width='100%' cellspacing='0' cellpadding='0'>
	<tr class='tr1'>
		<th width='20'>
			<div><b>$uName</b></div>
			<div><img src='image/head/$head'></div>
			<div>注册：$regTime</div>
		</th>
		<th width='80'>
		
			<div><h4>$title<h4></div>
			<div>$content</div>
			<div class='tipad gray'>发表：[$publishTime]&nbsp;&nbsp;&nbsp;最后修改：[$modifyTime]</div>
		</th>
	</tr>
</table>";
echo "</div>";
	}
}
?>



<?php
pageFoot();//调用函数输出页面尾部
?>
</body>