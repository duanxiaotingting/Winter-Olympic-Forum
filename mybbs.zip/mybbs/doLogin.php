<?php
header("content-type:text/html;charset=utf-8");  //指定编码方式
require_once("comm/user.dao.php");  //引入外部文件
if(!empty($_POST)){//如果服务器接收到了表单数据
	$rs = findUser($_POST["uName"]);//根据用户名查询用户信息，来自用户接口
	if(empty($rs)){//如果$rs为空，说明你的昵称无效
		echo "<script>alert('对不起，用户昵称错误!');location.href='login.php';</script>";
	}else{//如果$rs非空，说明昵称正确，但是密码正确与否不太清楚
		if($_POST["uPass"] == $rs[0]["uPass"]){//如果前端表单给的密码与数据库中存的密码相同
			session_start();//开启会话机制
			$_SESSION["CURRENT_USER"] = $rs[0];//将登陆成功用户信息存入会话中
			echo "<script>alert('恭喜你，登陆成功!');location.href='index.php';</script>";//弹窗提醒,页面跳转
		}else{
			echo "<script>alert('对不起，密码错误!');location.href='login.php';</script>";//弹窗提醒，页面跳转
		}
	}
}
?>