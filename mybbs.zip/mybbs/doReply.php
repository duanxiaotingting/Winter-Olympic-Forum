<?php
header("content-type:text/html;charset=utf-8");//指定编码方式
require_once("comm/reply.dao.php");            //引入外部文件
session_start();  //开启会话机制
if(isset($_SESSION["CURRENT_USER"])){//判断session会话变量是否被定义
   $uId = $_SESSION["CURRENT_USER"]["uId"];//从session会话中提取用户编号信息
   $title = $_POST["title"];//获取表单提交的回帖标题
   $content  = $_POST["content"];//获取表单提交的回帖内容
   $boardId = $_POST["boardId"];//获取表单提交的板块编号

	$curPage = $_POST["curPage"];//获取表单提交的列表页页码
	$topicId = $_POST["topicId"];//获取表单提交的帖子编号



   $rs = addReply($uId,$topicId,$title,$content);//向Reply表中插入一条记录
   if($rs == 1)
   echo "<script>alert('恭喜，回帖发布成功！');location.href='detail.php?boardId=$boardId&currentPage=$curPage&topicId=$topicId&currentReplyPage=1';</script>";
}else{
    echo "<script>alert('对不起，请先登录！');location.href='login.php';</script>";
}
?>