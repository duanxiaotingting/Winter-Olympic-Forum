<head>
	<title>论坛系统--首页</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8">
	<link rel="stylesheet" type="text/css" href="style/style.css"/>
	<body background="image/1.png"></body>
</head>
<body>
<?php
require_once("comm/comm.php");//引入外部文件
pageHead();//调用函数输出页面头部
?>

<!--页面中部：论坛首页-->
<div class="t">
<table width="100%" cellspacing="0" cellpadding="0">
	<tr class="tr2" align="center">
	<td colspan="2" width="50">版块名称</td>
	<td width="20%">主题数目</td>
	<td width="30%">最后发表</td>
	</tr>
	
	<?php
require_once("comm/board.dao.php");//引入外部接口文件
require_once("comm/topic.dao.php");//引入外部接口文件
	$boards = findListBoard(0);//根据parentID=0寻找所有的顶级板块
	foreach($boards as $value){//遍历顶层版块信息构成的二维数组
		$boardName = $value["boardName"];//提取某个顶层版块的版块名称
		echo "<tr class='tr3'>";
		echo "<td colspan='4'>$boardName</td>";//输出版块名称
		echo "</tr>";
	
	$boardId = $value["boardId"];//提取某个顶层版块的版块编号
	$sonBoards = findListBoard($boardId);//根据parentId寻找子版块信息
	foreach($sonBoards as $vv){//遍历子版块信息构成的二维数组
		$sonName = $vv["boardName"];//提取某个子版块的版块名称
		$sonId = $vv["boardId"];//提取某个子版块的版块编号
		$num = findCountTopic($sonId);//统计某个子版块下的帖子总数
		$topic = findLastTopic($sonId);//查询某个子版块下最新的主贴记录，结果为二维数组
		$title = $topic[0]["title"];//从最新的帖子信息里提取帖子标题
		$uName = $topic[0]["uName"];//从最新的帖子信息里提取发帖人的账号
		$publishTime = $topic[0]["publishTime"];//从最新的帖子信息里提取帖子发表时间
		$topicId = $topic[0]["topicId"];//从最新的帖子信息里提取对应的帖子编号
		
		echo "<tr class='tr3'>";
		echo "<td>&nbsp;</td>";
		echo "<td><img src='image/board.gif'><a href='list.php?boardId=$sonId&currentPage=1'>$sonName</a></td>";//制作超级链接，跳转时需要携带2个参数:第一个为当前子版块的版块编号,第二个为列表页页码，默认为1
		echo "<td align='center'>$num</td>";
		echo "<td>";
		echo "<span><a href='detail.php?boardId=$sonId&currentPage=1&topicId=$topicId&currentReplyPage=1'>$title</a></span><br>";//制作超级链接，跳转时需要携带四个参数：第一个为当前帖子所在版块的编号，第二个为列表页页码，第三个为当前帖子的编号，第四个参数为详情页页码
		echo "<span>$uName</span>";
		echo "<span>[$publishTime]</span>";
		echo "</td>";
		echo "</tr>";
	
	
	
	}
	
	
	
	
	
	
	
	}	
	?>
	
	
</table>
</div>

<?php
pageFoot();//调用函数输出页面尾部
?>
</body>